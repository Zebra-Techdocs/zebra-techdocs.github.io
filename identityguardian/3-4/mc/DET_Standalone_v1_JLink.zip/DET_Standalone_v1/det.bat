@echo off
setlocal EnableExtensions EnableDelayedExpansion

:: =========================================================
:: ISOLATION SANDBOX: Block host variables from interfering
:: =========================================================
set "JAVA_HOME="
set "CLASSPATH="
set "_JAVA_OPTIONS="
set "Path=%SystemRoot%\system32;%SystemRoot%"

:: Added Version Variable here
set "VERSION=1.0"

title Zebra Identity Guardian - Auto Key Generator v%VERSION%
color 0A
cls

:: Resolve the dynamic base directory
set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"

:: Define core paths
set "JAVA_EXE=!BASE_DIR!\jre\bin\java.exe"
set "PKG_NAME=com.zebra.mdna.els"
set "IN_SIG=!BASE_DIR!\input\signature.txt"
set "INPUT_DIR=!BASE_DIR!\input"
set "OUTPUT_DIR=!BASE_DIR!\output"
set "LIB_DIR=!BASE_DIR!\lib"

:: =========================================================
:: CONFIGURATION: Main Class for Kotlin-based library
:: =========================================================
set "MAIN_CLASS=MainKt"

:: =========================================================
:: DYNAMICALLY BUILD THE CLASSPATH (Links all JARs in \lib)
:: =========================================================
set "CP="
for %%J in ("!LIB_DIR!\*.jar") do (
    set "CP=!CP!;%%~fJ"
)
:: Remove the leading semicolon
set "CP=!CP:~1!"

echo ====================================================================
echo             ZEBRA IDENTITY GUARDIAN - AUTO KEY GENERATOR
echo                               v!VERSION!
echo ====================================================================
echo.

:: 1. Verify Java Executable and Libraries
if not exist "!JAVA_EXE!" (
    echo [ERROR] Bundled JRE not found at: !JAVA_EXE!
    echo.
    pause
    exit /b 1
)
if not exist "!LIB_DIR!\DataSecurity-1.0.jar" (
    echo [ERROR] Core library DataSecurity-1.0.jar not found in \lib!
    echo.
    pause
    exit /b 1
)

:: 2. Verify Signature File
if not exist "!IN_SIG!" (
    echo [ERROR] Missing input\signature.txt file!
    echo.
    pause
    exit /b 1
)

:: 3. Self-Healing: Ensure Output Directory Exists
if not exist "!OUTPUT_DIR!" (
    mkdir "!OUTPUT_DIR!"
)

:: 4. Scan and Process Keys
set "FILES_PROCESSED=0"
echo Scanning input folder for keys...
echo.

for %%F in ("!INPUT_DIR!\*.txt") do (
    :: Ensure we do not process the signature file itself
    if /I not "%%~nxF"=="signature.txt" (
        set /a FILES_PROCESSED+=1
        
        :: Define input and output paths dynamically
        set "CURRENT_FILE=%%~fF"
        set "OUT_FILE=!OUTPUT_DIR!\%%~nF_encrypted.txt"
        
        echo [!FILES_PROCESSED!] Encrypting: %%~nxF ...
        
        :: Execute Java using the dynamically built Classpath
        "!JAVA_EXE!" -cp "!CP!" !MAIN_CLASS! -dp "!CURRENT_FILE!" -p "!PKG_NAME!" -sp "!IN_SIG!" > "!OUT_FILE!"
    )
)

:: 5. Completion Summary
echo.
echo ====================================================================
if !FILES_PROCESSED! GTR 0 (
    echo [SUCCESS] !FILES_PROCESSED! files generated successfully.
    echo.
    echo Please check the output folder for your EMM-ready files.
) else (
    echo [WARNING] No valid .txt files found in the input folder.
    echo Make sure to place your keys there.
)
echo ====================================================================
echo.
echo Press any key to exit this tool...
pause >nul
endlocal

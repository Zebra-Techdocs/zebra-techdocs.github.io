====================================================================
ZEBRA IDENTITY GUARDIAN - DATA ENCRYPTION TOOL (STANDALONE)
====================================================================

VERSION: 1.0

OVERVIEW
--------
This standalone package simplifies the deployment of Zebra Identity Guardian 
by automatically generating the necessary encrypted Enrollment and 
Authentication keys required by Secure Storage Manager (SSM).

This tool is entirely self-contained. No installation of Java or manual 
configuration of security libraries is required.


FOLDER STRUCTURE
----------------
When you extract the ZIP file, you will see the following structure:

* input/      - Place your unencrypted keys and signature file here.
* output/     - Your encrypted, EMM-ready keys will appear here.
* det.bat     - The application script you double-click to run the tool.

(Note: Do not modify the "lib" or "jre" folders, as these contain the 
core encryption engine).


PREREQUISITES: PREPARING YOUR KEYS
----------------------------------
Before using this tool, you must generate a standard 2048-bit RSA key pair. 
Identity Guardian requires the Private Key to be in strict PKCS#8 format.

If you have Git or OpenSSL installed, open a terminal and run the 
following commands to generate valid keys:

1. Generate Private Key (Authentication):
   openssl genpkey -algorithm RSA -out private_key.txt -pkeyopt rsa_keygen_bits:2048

2. Extract Public Key (Enrollment):
   openssl rsa -pubout -in private_key.txt -out public_key.txt


HOW TO USE THE KEY GENERATOR
----------------------------

Step 1: Place Your Input Files
Open the "input" folder inside the tool directory and place these files inside:
  1. Your Public Key .txt file (e.g., public_key.txt).
  2. Your Private Key .txt file (e.g., private_key.txt).
  3. signature.txt (The Zebra Identity Guardian Base64 signature file. 
     Do not delete or rename this file).

Step 2: Run the Tool
  1. Navigate back to the main folder containing the tool.
  2. Double-click "det.bat".
  3. A console window will briefly appear. The tool will automatically 
     scan the "input" folder, encrypt every .txt file it finds (safely 
     ignoring the signature.txt file), and save them.
  4. Once the process is complete, the tool will display a success message 
     and prompt you to press any key to close the window.

Step 3: Retrieve Your Encrypted Keys
  1. Open the "output" folder.
  2. You will see new files corresponding to your inputs (e.g., 
     public_key_encrypted.txt, private_key_encrypted.txt).
  3. Open these files in Notepad (ensure "Word Wrap" is disabled 
     via the View menu).
  4. Copy the massive, unbroken Base64 string (including the leading ##). 
     Ensure you do not copy any blank spaces at the end of the line.


DEPLOYING THE KEYS TO IDENTITY GUARDIAN
---------------------------------------
Paste the copied strings into your Enterprise Mobility Management (EMM) 
console under the Identity Guardian Managed Configurations:

* Public Key Output  --> Paste into the "Enrollment Key" field.
* Private Key Output --> Paste into the "Authentication Key" field.

Once the configuration is pushed to the device, Secure Storage Manager (SSM) 
will securely intercept, decrypt, and validate these keys for Identity Guardian.
====================================================================

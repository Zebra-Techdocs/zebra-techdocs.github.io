//
//  ReaderModel.h
//  NewGen2XPlay
//
//  Created by Kakarlapudi, Prudhvi on 06/04/26.
//

#import <Foundation/Foundation.h>

@interface ReaderModel : NSObject

@property (nonatomic, strong) NSString *readerID;
@property (nonatomic, assign) BOOL isConnected;

@end

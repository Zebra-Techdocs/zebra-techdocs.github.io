//
//  ReaderModel.m
//  NewGen2XPlay
//
//  Created by Kakarlapudi, Prudhvi on 06/04/26.
//

#import "ReaderModel.h"

@implementation ReaderModel
@end

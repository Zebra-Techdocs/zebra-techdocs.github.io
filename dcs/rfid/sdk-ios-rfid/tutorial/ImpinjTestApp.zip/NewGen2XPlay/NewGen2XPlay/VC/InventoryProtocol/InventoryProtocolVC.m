//
//  InventoryProtocolVC.m
//  NewGen2XPlay
//
//  Created by Kakarlapudi, Prudhvi on 13/04/26.
//

#import <Foundation/Foundation.h>
#import "InventoryProtocolVC.h"
#import "AppConstants.h"

@interface InventoryProtocolVC ()
@property (weak, nonatomic) IBOutlet UIButton *saveButton;
@property (weak, nonatomic) IBOutlet UILabel *currentModeLabel;
@property (weak, nonatomic) IBOutlet UIButton *gen2Button;
@property (weak, nonatomic) IBOutlet UIButton *gen2xButton;
@property (weak, nonatomic) IBOutlet UIButton *hybridButton;
@property (strong, nonatomic) NSArray<UIButton *> *modeButtons;
@property (weak, nonatomic) IBOutlet UIView *containerView;

@property (nonatomic, assign) SRFID_ENUM_INVENTORY_PROTOCOL selectedProtocol;
@end

@implementation InventoryProtocolVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = INVENTORY_PROTOCOL_VC_TITLE;

    self.modeButtons = @[self.gen2Button, self.gen2xButton, self.hybridButton];

    // IMPORTANT: set tags to enum values (do this in storyboard ideally)
    self.gen2Button.tag = GEN2;
    self.gen2xButton.tag = GEN2X;
    self.hybridButton.tag = HYBRID;

    [self setupSegmentedControl];

    // Restore saved selection (or default to GEN2)
    [self restoreSelectedProtocol];

//    UIImage *infoButtonImage = [[UIImage systemImageNamed:@"info"]
//                                imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
//
//    UIBarButtonItem *infoBarButtonItem =
//        [[UIBarButtonItem alloc] initWithImage:infoButtonImage
//                                         style:UIBarButtonItemStylePlain
//                                        target:self
//                                        action:@selector(infoButtonTapped)];
//
//    infoBarButtonItem.tintColor = UIColor.systemBlueColor; 
//    self.navigationItem.rightBarButtonItem = infoBarButtonItem;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self getProtocol];
}

- (void)setupSegmentedControl {
    self.containerView.layer.borderWidth = 1;
    self.containerView.layer.cornerRadius = 44 / 2;
    self.containerView.layer.borderColor = [UIColor redColor].CGColor;
    self.containerView.clipsToBounds = YES;

    for (UIButton *btn in self.modeButtons) {
        btn.backgroundColor = UIColor.clearColor;
        [btn setTitleColor:UIColor.darkTextColor forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    }
}

#pragma mark - UI Selection

- (IBAction)modeButtonTapped:(UIButton *)sender {
    if (sender.selected) return;

    self.selectedProtocol = (SRFID_ENUM_INVENTORY_PROTOCOL)sender.tag;
    [self setSelectedModeButton:sender];
}

- (void)setSelectedModeButton:(UIButton *)selectedButton {
    for (UIButton *btn in self.modeButtons) {
        BOOL isSelected = (btn == selectedButton);
        btn.selected = isSelected;

        if (isSelected) {
            [btn setTitleColor:[UIColor systemBlueColor] forState:UIControlStateNormal];
        } else {
            [btn setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
        }
    }

    NSString *title = selectedButton.titleLabel.text ?: @"";
    self.currentModeLabel.text = [NSString stringWithFormat:@"Current: %@", title.uppercaseString];
}

#pragma mark - Save button

- (IBAction)saveButtonTapped:(UIButton *)sender {
    // APPLY the selected protocol, not the save button tag
    [self setInventoryProtocol:self.selectedProtocol];
}

#pragma mark - Save & Restore

- (void)saveSelectedProtocol:(SRFID_ENUM_INVENTORY_PROTOCOL)protocol {
    [[NSUserDefaults standardUserDefaults] setInteger:protocol forKey:SELECTED_PROTOCOL_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)restoreSelectedProtocol {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    SRFID_ENUM_INVENTORY_PROTOCOL p = GEN2; // default
    if ([defaults objectForKey:SELECTED_PROTOCOL_KEY] != nil) {
        p = (SRFID_ENUM_INVENTORY_PROTOCOL)[defaults integerForKey:SELECTED_PROTOCOL_KEY];
    }

    self.selectedProtocol = p;

    switch (p) {
        case GEN2:   [self setSelectedModeButton:self.gen2Button]; break;
        case GEN2X:  [self setSelectedModeButton:self.gen2xButton]; break;
        case HYBRID: [self setSelectedModeButton:self.hybridButton]; break;
        default:     [self setSelectedModeButton:self.gen2Button]; self.selectedProtocol = GEN2; break;
    }
}

#pragma mark - Set Inventory Protocol (unified)

-(void)getProtocol {
    
    srfidAttribute *attributeInfo = nil;
    NSString *status = nil;
    
    attributeInfo = [[srfidAttribute alloc] init];
    [attributeInfo setAttrNum:2546];
    [attributeInfo setAttrType:@"B"];
    
    SRFID_ENUM_INVENTORY_PROTOCOL protocolEnum ;
    SRFID_RESULT result = SRFID_RESULT_FAILURE;
    
    result = [[ZebraServiceEngine sharedInstance]  getReaderInventoryProtocol:&protocolEnum aStatusMessage:&status];
    

    
    if (result == SRFID_RESULT_SUCCESS && attributeInfo != nil) {
        NSString *protocolName;
           switch (protocolEnum) {
               case GEN2:
                   protocolName = @"GEN2";
                   break;
               case GEN2X:
                   protocolName = @"GEN2X";
                   break;
               case HYBRID:
                   protocolName = @"HYBRID";
                   break;
               default:
                   protocolName = @"UNKNOWN";
                   break;
           }
        NSLog(@"Get ProtocolName*: %@", protocolName);
        [self saveSelectedProtocol:protocolEnum];
    } else {
        NSLog(@"Failed to get protocol. Status: %@", status);
    }
}

-(void)setInventoryProtocol:(SRFID_ENUM_INVENTORY_PROTOCOL)protocol {
    int connectedId = [[ZebraServiceEngine sharedInstance] getConnectedReaderId];
    NSLog(@"[DEBUGG] connectedId=%d", connectedId);
    NSLog(@"[DEBUGG] GEN2=%d GEN2X=%d HYBRID=%d", GEN2, GEN2X, HYBRID);
    NSLog(@"[DEBUGG] Trying to set protocol enum value: %ld", (long)protocol);
    SRFID_RESULT result = SRFID_RESULT_FAILURE;
    NSString *status = nil;
    NSString *protocolName;
       switch (protocol) {
           case GEN2:
               protocolName = @"GEN2";
               break;
           case GEN2X:
               protocolName = @"GEN2X";
               break;
           case HYBRID:
               protocolName = @"HYBRID";
               break;
           default:
               protocolName = @"UNKNOWN";
               break;
       }
    
    result = [[ZebraServiceEngine sharedInstance]  setReaderInventoryProtocol:protocol aStatusMessage:&status];
    NSLog(@"[DEBUGG]setReaderInventoryProtocol result=%ld status=%@", (long)result, status);

    if (result == SRFID_RESULT_SUCCESS) {
        // Save selection only on success
        [self saveSelectedProtocol:protocol];
        [self getProtocol];
    }
    
    NSString *prefix = (result == SRFID_RESULT_SUCCESS) ? @"Success" : @"Failed";
    NSString *message = [NSString stringWithFormat:@"%@: Inventory protocol set to %@", prefix, protocolName];
    [self showAlertMessageWithTitle:ZT_RFID_APP_NAME withMessage:message];
}
//#pragma mark - Info Button Alert
//- (void)infoButtonTapped {
//    NSString *appVersion =
//        [@"App Version: " stringByAppendingString:
//         [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"]];
//
//    NSString *sdkVersion =
//        [@"\nSDK Version: " stringByAppendingString:
//         [[ZebraServiceEngine sharedInstance] getSDKVersion]];
//
//    NSString *msg = [appVersion stringByAppendingString:sdkVersion];
//
//    UIAlertController *alertController =
//        [UIAlertController alertControllerWithTitle:APP_INFO
//                                            message:msg
//                                     preferredStyle:UIAlertControllerStyleAlert];
//
//    UIAlertAction *ok =
//        [UIAlertAction actionWithTitle:@"OK"
//                                 style:UIAlertActionStyleDefault
//                               handler:nil];
//
//    [alertController addAction:ok];
//    [self presentViewController:alertController animated:YES completion:nil];
//}
#pragma mark - Alert Helper

/// Display alert message
/// @param title Title string
/// @param message Message string
-(void)showAlertMessageWithTitle:(NSString*)title withMessage:(NSString*)message {
    UIAlertController *alert = [UIAlertController
                    alertControllerWithTitle:title
                                    message:message
                             preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okButton = [UIAlertAction
                        actionWithTitle:@"OK"
                                  style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction *action) {
                                    // Handle ok action
                                }];
    [alert addAction:okButton];
    [self presentViewController:alert animated:YES completion:nil];
}


@end

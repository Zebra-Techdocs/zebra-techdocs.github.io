//
//  InventoryProtocolVC.h
//  NewGen2XPlay
//
//  Created by Kakarlapudi, Prudhvi on 13/04/26.
//

#import <UIKit/UIKit.h>
#import "ZebraServiceEngine.h"
#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface InventoryProtocolVC : BaseViewController

@end

NS_ASSUME_NONNULL_END

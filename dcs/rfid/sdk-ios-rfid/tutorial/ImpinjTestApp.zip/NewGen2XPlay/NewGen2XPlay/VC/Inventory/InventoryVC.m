//
//  InventoryVC.m
//  NewGen2XPlay
//
//  Created by Dhanushka, Adrian on 2026-02-23.
//

#import "InventoryVC.h"
#import "ImpinjCustomTableViewCell.h"
#import "ReadRateAlertView.h"
// Start and Stop icons for scanner start and stop action.
#define START_SCAN_ICON @"start_scan_icon"
#define STOP_SCAN_ICON @"stop_scan_icon"

#define MAX_SELECTED_TAGS 31

@interface InventoryVC ()
@property(atomic, assign) BOOL inventoryRunning;
@property(atomic, assign) BOOL inventoryStartStopInProgress;

@property(nonatomic, strong) NSTimer *quietCycleTimer;
@property(nonatomic, assign) NSInteger currentQuietChunkIndex;
@property(nonatomic, assign) BOOL isQuietCycleActive;

@property (nonatomic, strong) UIView *overlayView;
@property (nonatomic, strong) ReadRateAlertView *readRateAlert;
@end

@implementation InventoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [ZebraServiceEngine sharedInstance].delegateTagDataEvent = self;
    
    self->tblImpinjInventory.delegate = self;
    self->tblImpinjInventory.dataSource = self;
    self.secondsElapsed = 0;
    // Do any additional setup after loading the view.
    
    _currentlySelectedTagIdObjectArray = [NSMutableArray array];
    _tagReadRateDictionary = [NSMutableDictionary dictionary];
    _selectedRows = [NSMutableArray array];
    
    _tagAvgReadRateDictionary = [[NSMutableDictionary alloc] init];
    
    _uniqueTagCountAtLastInterval = 0; //
    
    _quietedTagIDs = [NSMutableSet set];
    
    coutGreen = 0;
    coutGray = 0;
    coutWhite = 0;
    coutYellow = 0;
    //    [self defultFastIDMode];
    self.inventoryRunning = NO;
    self.inventoryStartStopInProgress = NO;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self navigationBarRight];
    
    [[ZebraServiceEngine sharedInstance]  addTriggerEventDelegate:self];
    BOOL isRunning = [[NSUserDefaults standardUserDefaults]
                      boolForKey:@"IsInventoryRunning"];
    
    if (isRunning) {
        [UIView performWithoutAnimation:^{
            [btnImpinjInvStart setImage:[UIImage imageNamed:STOP_SCAN_ICON]
                               forState:UIControlStateNormal];
            [btnImpinjInvStart setSelected:YES];
            [btnImpinjInvStart layoutIfNeeded];
        }];
        
        // Update timer label immediately with current elapsed time
        [self updateTimer];
        
        // Restart the timer if it's not already running
        if (!self.countdownTimer || ![self.countdownTimer isValid]) {
            self.countdownTimer =
            [NSTimer timerWithTimeInterval:1.0
                                    target:self
                                  selector:@selector(updateTimer)
                                  userInfo:nil
                                   repeats:YES];
            [[NSRunLoop mainRunLoop] addTimer:self.countdownTimer
                                      forMode:NSRunLoopCommonModes];
        }
    } else {
        [UIView performWithoutAnimation:^{
            [btnImpinjInvStart setImage:[UIImage imageNamed:START_SCAN_ICON]
                               forState:UIControlStateNormal];
            [btnImpinjInvStart setSelected:NO];
            [btnImpinjInvStart layoutIfNeeded];
        }];
        
        //  Reset timer display when inventory is not running
        self.secondsElapsed = 0;
        self->lbTimer.text = @"00:00";
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[ZebraServiceEngine sharedInstance] removeTriggerEventDelegate:self];
}

-(void)navigationBarRight {
    
    UIImage *img = [[UIImage imageNamed:@"ic_read_rate"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIBarButtonItem *readRateItem =
    [[UIBarButtonItem alloc] initWithImage:img
                                     style:UIBarButtonItemStylePlain
                                    target:self
                                    action:@selector(showReadRateAlert)];
    
    NSMutableArray<UIBarButtonItem *> *items =
    [self.navigationItem.rightBarButtonItems mutableCopy] ?: [NSMutableArray new];
    
    // Put screen button closer to title (left side within right items)
    [items addObject:readRateItem];
    
    self.navigationItem.rightBarButtonItems = items;
    
}

- (void)showReadRateAlert {
    // Prevent showing multiple alerts
       if (self.readRateAlert) {
           return;
       }
    [self updateTimer];
    // Overlay
        self.overlayView = [[UIView alloc] initWithFrame:self.view.bounds];
        self.overlayView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.4];
        [self.view addSubview:self.overlayView];

        // Alert
        self.readRateAlert = [[ReadRateAlertView alloc] init];
        self.readRateAlert.translatesAutoresizingMaskIntoConstraints = NO;
        [self.view addSubview:self.readRateAlert];

        [NSLayoutConstraint activateConstraints:@[
            [self.readRateAlert.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [self.readRateAlert.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
            [self.readRateAlert.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:0.8]
        ]];

    // ---- compute numbers from InventoryVC state ----
    NSInteger totalReads = self->_totalReadCount;
    NSTimeInterval elapsed = [self currentInventoryElapsedTime];
    double readRate = (elapsed > 0) ? ((double)totalReads / elapsed) : 0.0;

        [self.readRateAlert configureWithTotalReads:totalReads totalTime:elapsed readRate:readRate];

        __weak typeof(self) weakSelf = self;
        self.readRateAlert.dismissAction = ^{
            [weakSelf dismissreadRateAlert];
        };

        // Animate
        self.overlayView.alpha = 0;
        self.readRateAlert.alpha = 0;
        self.readRateAlert.transform = CGAffineTransformMakeScale(1.1, 1.1);

        [UIView animateWithDuration:0.3 animations:^{
            weakSelf.overlayView.alpha = 1;
            weakSelf.readRateAlert.alpha = 1;
            weakSelf.readRateAlert.transform = CGAffineTransformIdentity;
        }];
    }

   // --- Method to hide and clean up the alert ---
   - (void)dismissreadRateAlert {
       [UIView animateWithDuration:0.25 animations:^{
           self.overlayView.alpha = 0;
           self.readRateAlert.alpha = 0;
           self.readRateAlert.transform = CGAffineTransformMakeScale(0.9, 0.9);
       } completion:^(BOOL finished) {
           [self.overlayView removeFromSuperview];
           [self.readRateAlert removeFromSuperview];
           self.overlayView = nil;
           self.readRateAlert = nil;
       }];
   }

- (NSTimeInterval)currentInventoryElapsedTime {
    return (NSTimeInterval)self.secondsElapsed;
}

- (void)defultFastIDMode {

    NSString *status = [[NSString alloc] init];

    [[ZebraServiceEngine sharedInstance] configureFastID:NO status:&status];
    [[ZebraServiceEngine sharedInstance] setFastIDEnableStatue:NO];

    [UIView performWithoutAnimation:^{
      [btnFastID setImage:[UIImage imageNamed:@"checkbox_icon"]
                 forState:UIControlStateNormal];
      [btnFastID setSelected:NO];
      [btnFastID layoutIfNeeded];
    }];
}

#pragma mark - Inventory Tag data  Delegate
- (void)eventTagDataRecived:(ZebraServiceEngine *)zebraServiceEngine
    didFinishEventTagDataRecived:(srfidTagData *)tagData {
    NSString *newTagId = [tagData getTagId];

    // Calculate elapsed time on background thread (read-only, safe)
    if (!_scanStartTime) {
        _scanStartTime = [NSDate date];
    }
    _totalReadCount++;
    NSTimeInterval elapsedTime =
        [[NSDate date] timeIntervalSinceDate:_scanStartTime];

    // Move ALL mutable collection mutations to the main thread
    dispatch_async(dispatch_get_main_queue(), ^{
      if (!self->_tagDataInventory) {
          self->_tagDataInventory = [NSMutableArray array];
      }
      if (!self->_tagCountDictionary) {
          self->_tagCountDictionary = [NSMutableDictionary dictionary];
      }
      if (!self->_tagReadRateDictionary) {
          self->_tagReadRateDictionary = [NSMutableDictionary dictionary];
      }

      // Track occurrence count
      if (self->_tagCountDictionary[newTagId]) {
          int currentCount = [self->_tagCountDictionary[newTagId] intValue];
          currentCount++;
          self->_tagCountDictionary[newTagId] = @(currentCount);
      } else {
          self->_tagCountDictionary[newTagId] = @(1);
      }

      // Add to unique list
      BOOL isDuplicate = NO;
      for (srfidTagData *existingTag in self->_tagDataInventory) {
          if ([[existingTag getTagId] isEqualToString:newTagId]) {
              isDuplicate = YES;
              break;
          }
      }
        
      BOOL wasNewlyAdded = NO;
      if (!isDuplicate) {
          [self->_tagDataInventory addObject:tagData];
          wasNewlyAdded = YES;
          
          if (self.isQuietCycleActive) {
            // Add to the background tracking arrays automatically
            [self->_currentlySelectedTagIdObjectArray addObject:tagData];
            NSIndexPath *newIdx = [NSIndexPath indexPathForRow:(self->_tagDataInventory.count - 1) inSection:0];
            [self.selectedRows addObject:newIdx];
            // Add to quieted tags so it instantly turns yellow in the UI
            [self.quietedTagIDs addObject:newTagId];
         }
          
          
      }

      // Grow checkedStates (never rebuild)
      if (!self.checkedStates) {
          self.checkedStates = [NSMutableArray array];
      }
        while (self.checkedStates.count < self->_tagDataInventory.count) {
            BOOL initialState = NO;
            // Apply the visual checkmark if Tag Quiet is running, but respect the 31 limit for the UI
            if (self.isQuietCycleActive && self.checkedStates.count < MAX_SELECTED_TAGS) {
                initialState = YES;
            }
            [self.checkedStates addObject:@(initialState)];
        }
        
        // If a new tag arrived while Tag Quiet is running, refresh the hardware.
        // We use a 1-second delay so if 10 tags arrive instantly, it only restarts the reader ONCE.
        if (wasNewlyAdded && self.isQuietCycleActive) {
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(updateActiveTagQuietFilters) object:nil];
            [self performSelector:@selector(updateActiveTagQuietFilters) withObject:nil afterDelay:1.0];
        }


      // Calculate read rate (only after 1 second)
      if (elapsedTime >= 1.0) {
          int tagCount = [self->_tagCountDictionary[newTagId] intValue];
          double tagReadRate = tagCount / elapsedTime;
          self->_tagReadRateDictionary[newTagId] = @(tagReadRate);

          if (![self.quietedTagIDs containsObject:newTagId]) {
              [self->_tagAvgReadRateDictionary setObject:@(tagReadRate)
                                                  forKey:newTagId];
          }
      }

      // Recalculate and update UI
      [self recalculateColorCounts];

      [self->tblImpinjInventory reloadData];
      self->lbUniqeCount.text = [NSString
          stringWithFormat:@"%lu",
                           (unsigned long)[self->_tagDataInventory count]];
      self->lbGrayCount.text =
          [[NSNumber numberWithInt:self->coutGray] stringValue];
      self->lbGreenCount.text =
          [[NSNumber numberWithInt:self->coutGreen] stringValue];
      self->lbYellowCount.text =
          [[NSNumber numberWithInt:self->coutYellow] stringValue];
      self->lbWhiteCount.text =
          [[NSNumber numberWithInt:self->coutWhite] stringValue];
    });
}

#pragma mark - Unique Tag Interval Counter

- (void)updateNewUniqueTagCount {
    NSInteger currentTotal = [_tagDataInventory count];
    NSInteger newUniqueTags = currentTotal - _uniqueTagCountAtLastInterval;
    _uniqueTagCountAtLastInterval = currentTotal;

    lbNewUniqueTagCounter.text =
        [NSString stringWithFormat:@"New Unique tags every 10s : %ld",
                                   (long)newUniqueTags];
}

- (void)recalculateColorCounts {
    // No snapshots needed — this is now always called on the main thread

    double sum = 0.0;
    int activeCount = 0;

    for (NSString *key in _tagAvgReadRateDictionary) {
        if ([self.quietedTagIDs containsObject:key]) {
            continue;
        }
        sum += [_tagAvgReadRateDictionary[key] doubleValue];
        activeCount++;
    }

    double averageRate = 0.0;
    if (activeCount > 0) {
        averageRate = sum / activeCount;
    }

    int greenCount = 0;
    int grayCount = 0;
    int whiteCount = 0;
    int yellowCount = 0;

    for (srfidTagData *tag in _tagDataInventory) {
        NSString *tagId = [tag getTagId];

        if ([self.quietedTagIDs containsObject:tagId]) {
            yellowCount++;
            continue;
        }

        NSNumber *rateNumber = _tagAvgReadRateDictionary[tagId];
        double rate = [rateNumber doubleValue];

        if (rate > averageRate) {
            greenCount++;
        } else if (rate < averageRate) {
            grayCount++;
        } else {
            whiteCount++;
        }
    }

    coutGreen = greenCount;
    coutGray = grayCount;
    coutWhite = whiteCount;
    coutYellow = yellowCount;
}

- (void)resetInventoryState {

    // Reset un-quiet button
    [UIView performWithoutAnimation:^{
      [self->btnTagUnquiet setImage:[UIImage imageNamed:@"checkbox_icon"]
                           forState:UIControlStateNormal];
      [self->btnTagUnquiet setSelected:NO];
      [self->btnTagUnquiet layoutIfNeeded];
    }];

    //  Reset select all button
    [UIView performWithoutAnimation:^{
      [self->btnSlectAllTags setImage:[UIImage imageNamed:@"checkbox_icon"]
                             forState:UIControlStateNormal];
      [self->btnSlectAllTags setSelected:NO];
      [self->btnSlectAllTags layoutIfNeeded];
    }];

    //  Preserve quieted tags and their data before clearing
    NSMutableArray *quietedTagsToKeep = [NSMutableArray array];
    for (srfidTagData *tag in self->_tagDataInventory) {
        if ([self.quietedTagIDs containsObject:[tag getTagId]]) {
            [quietedTagsToKeep addObject:tag];
        }
    }

    // Clear all data
    [self->_tagDataInventory removeAllObjects];
    [self->_tagCountDictionary removeAllObjects];
    [self->_tagReadRateDictionary removeAllObjects];
    [self->_tagAvgReadRateDictionary removeAllObjects];
    [self.checkedStates removeAllObjects];
    [self clearAllSelections];
    //  NOT clearing quietedTagIDs

    //  Restore quieted tags back into inventory
    [self->_tagDataInventory addObjectsFromArray:quietedTagsToKeep];

    //  Restore checkedStates for the preserved quieted tags
    for (int i = 0; i < quietedTagsToKeep.count; i++) {
        [self.checkedStates addObject:@(NO)];
    }

    // Reset read rate tracking
    self->_scanStartTime = nil;
    self->_totalReadCount = 0;

    // Reset color counters and recalculate with quieted tags
    self->coutGreen = 0;
    self->coutGray = 0;
    self->coutWhite = 0;
    self->coutYellow = (int)quietedTagsToKeep.count;

    // Reset unique tag interval counter
    self.uniqueTagCountAtLastInterval = quietedTagsToKeep.count;

    // Reset labels (yellow count reflects preserved quieted tags)
    self->lbUniqeCount.text = [NSString
        stringWithFormat:@"%lu", (unsigned long)quietedTagsToKeep.count];
    self->lbGreenCount.text = @"0";
    self->lbGrayCount.text = @"0";
    self->lbWhiteCount.text = @"0";
    self->lbYellowCount.text = [NSString
        stringWithFormat:@"%lu", (unsigned long)quietedTagsToKeep.count];
    self->lbNewUniqueTagCounter.text = @"New Unique tags every 10s : 0";

    // Reload table (will show only the yellow quieted rows)
    [self->tblImpinjInventory reloadData];
}

#pragma mark - Tag Focus

- (IBAction)btnTagFocusChecked:(id)sender {

    if (btnTagFocus.isSelected) {

        // 1. Update UI immediately on the Main Thread
        [UIView performWithoutAnimation:^{
          [btnTagFocus setImage:[UIImage imageNamed:@"checkbox_icon"]
                       forState:UIControlStateNormal];
          [btnTagFocus setSelected:NO];
          [btnTagFocus layoutIfNeeded];
        }];

        dispatch_async(
            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
              SRFID_RESULT tagFocusResult = SRFID_RESULT_FAILURE;
              NSString *status2 = [[NSString alloc] init];
              tagFocusResult =
                  [[ZebraServiceEngine sharedInstance] enableTagFocus:NO
                                                               status:&status2];

              dispatch_async(dispatch_get_main_queue(), ^{
                if (tagFocusResult == SRFID_RESULT_SUCCESS) {
                    [self->_tagDataInventory removeAllObjects];
                    [self clearAllSelections];
                    [self->tblImpinjInventory reloadData];
                    [self->_tagCountDictionary removeAllObjects];
                    self->_hasTagFocusEnabled = YES;
                    [[NSUserDefaults standardUserDefaults]
                        setBool:NO
                         forKey:@"TagFocusEnabled"];
                    [[NSUserDefaults standardUserDefaults] synchronize];

                    NSString *status = [[NSString alloc] init];
                    SRFID_RESULT delete_prefilters =
                        [[ZebraServiceEngine sharedInstance]
                            deleteAllPrefilter:&status];
                    [[ZebraServiceEngine sharedInstance] resetPrefilters];

                    NSLog(@"Tag Focus Result: %u", tagFocusResult);
                    NSLog(@"Tag Focus Result Delete Prefilters: %u",
                          delete_prefilters);
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Tag Focus Disabled Successfully"];
                    });

                } else {
                    NSLog(@"Tag Focus Result: %u", tagFocusResult);
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Tag Focus Disable Failed"];
                    });
                }
              });
            });

    } else {
        [UIView performWithoutAnimation:^{
          [btnTagFocus setImage:[UIImage imageNamed:@"checkbox_checked_icon"]
                       forState:UIControlStateNormal];
          [btnTagFocus setSelected:YES];
          [btnTagFocus layoutIfNeeded];

          [btnFastID setImage:[UIImage imageNamed:@"checkbox_icon"]
                     forState:UIControlStateNormal];
          [btnFastID setSelected:NO];
          [btnFastID layoutIfNeeded];
        }];

        dispatch_async(
            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
              SRFID_RESULT tagFocusResult = SRFID_RESULT_FAILURE;

              NSString *response = @"";

              tagFocusResult = [[ZebraServiceEngine sharedInstance]
                  enableTagFocus:YES
                          status:&response];

              dispatch_async(dispatch_get_main_queue(), ^{
                if (tagFocusResult == SRFID_RESULT_SUCCESS) {
                    [self->_tagDataInventory removeAllObjects];
                    [self clearAllSelections];
                    [self->tblImpinjInventory reloadData];
                    [self->_tagCountDictionary removeAllObjects];
                    self->_hasTagFocusEnabled = YES;
                    [[NSUserDefaults standardUserDefaults]
                        setBool:YES
                         forKey:@"TagFocusEnabled"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    // no need this
                    //                    SRFID_RESULT set_prefilters =
                    //                    SRFID_RESULT_FAILURE;
                    //
                    //                    NSMutableArray *prefilters =
                    //                    [[NSMutableArray alloc] init];
                    //                    prefilters =  [[ZebraServiceEngine
                    //                    sharedInstance] getPrefilters];
                    //
                    NSLog(@"Tag Focus Result: %u", tagFocusResult);
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Tag Focus Enabled Successfully"];
                    });

                } else {
                    NSLog(@"Tag Focus Result: %u", tagFocusResult);
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Tag Focus Enable Failed"];
                    });
                }
              });
            });
    }
}

- (void)setSingulationForTagFocus {
    SRFID_SLFLAG sl_flag = SRFID_SLFLAG_ALL;
    SRFID_SESSION session = SRFID_SESSION_S1;
    SRFID_INVENTORYSTATE inv_state = SRFID_INVENTORYSTATE_A;

    srfidSingulationConfig *config = [[srfidSingulationConfig alloc] init];
    [config setSlFlag:sl_flag];
    [config setSession:session];
    [config setTagPopulation:200];
    [config setInventoryState:inv_state];

    SRFID_RESULT resultSigulation = SRFID_RESULT_FAILURE;
    NSString *response = @"";
    resultSigulation = [[ZebraServiceEngine sharedInstance]
        setSingulationConfigurationTagFoucus:config
                                      status:&response];
    if (resultSigulation == SRFID_RESULT_SUCCESS) {
        NSLog(@"Set Singulation Configuration for Tag Foucus SUCCESS");
    } else {
        NSLog(@"Set Singulation Configuration for Tag Foucus Failed");
    }
}

#pragma mark - Tag Quiet / Un-Quiet
- (IBAction)btnTagQuietPressed:(id)sender {
    [UIView performWithoutAnimation:^{
      [btnTagUnquiet setImage:[UIImage imageNamed:@"checkbox_icon"]
                     forState:UIControlStateNormal];
      [btnTagUnquiet setSelected:NO];
      [btnTagUnquiet layoutIfNeeded];
    }];

    [self enableTagQuiet];
}

- (void)enableTagQuiet {
    [[ZebraServiceEngine sharedInstance] resetPrefilters];
    [self setTagQuietPreFilterArray];
}

- (IBAction)btnTagUnquietPressed:(id)sender {
    if (btnTagUnquiet.isSelected) {
        [UIView performWithoutAnimation:^{
          [btnTagUnquiet setImage:[UIImage imageNamed:@"checkbox_icon"]
                         forState:UIControlStateNormal];
          [btnTagUnquiet setSelected:NO];
          [btnTagUnquiet layoutIfNeeded];
        }];
        

    } else {
        [UIView performWithoutAnimation:^{
          [btnTagUnquiet setImage:[UIImage imageNamed:@"checkbox_checked_icon"]
                         forState:UIControlStateNormal];
          [btnTagUnquiet setSelected:YES];
          [btnTagUnquiet layoutIfNeeded];
        }];
        
        // Kill cycle timer
        self.isQuietCycleActive = NO;
        [self.quietCycleTimer invalidate];
        self.quietCycleTimer = nil;


        [self->_currentlySelectedTagIdObjectArray removeAllObjects];

        //  Show loading for 8 seconds, then perform un-quiet
        [self
            showLoadingForSeconds:10
                          message:@"Un-Quieting Tags..."
                       completion:^{
                         

                         dispatch_async(
                             dispatch_get_global_queue(
                                 DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),
                             ^{
                               NSLog(@"Currently Selected Array: %@",
                                     self->_currentlySelectedTagIdObjectArray);
                               [[NSUserDefaults standardUserDefaults]
                                   synchronize];
                               NSString *status = [[NSString alloc] init];

                               [[ZebraServiceEngine sharedInstance]
                                   deleteAllPrefilter:nil];
                               [[ZebraServiceEngine sharedInstance]
                                   restorePrefiltersForTagQuet];
                               [[ZebraServiceEngine sharedInstance]
                                   resetPrefilters];

                               SRFID_RESULT resTagQuiteFinal =
                                   [[ZebraServiceEngine sharedInstance]
                                       enableTagQuiet:NO
                                              meesage:&status];

                               if (resTagQuiteFinal == SRFID_RESULT_SUCCESS) {
                                   [self.quietedTagIDs removeAllObjects];
                                   [[NSUserDefaults standardUserDefaults]
                                       setBool:YES
                                        forKey:@"TagQuietEnabled"];
                                   [[NSUserDefaults standardUserDefaults]
                                       synchronize];
                                   [self presentAlertWithMessage:@"Impinj Tag Un-Quiet Enabled" completion:^{
                                    // Programmatically press the clear button to wipe everything
                                    [self btnClearInventoryPressed:nil];
                                                                
                                    }];

                               } else {
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                     [self showAlert:@"Impinj Tag Quiet "
                                                     @"Disable Failed"];
                                   });
                               }
                             });
            
                       
            
                       }];
    }
}

- (void)presentAlertWithMessage:(NSString *)alertMsg completion:(void (^)(void))completion {
    dispatch_async(dispatch_get_main_queue(), ^{
      UIAlertController *alertController = [UIAlertController
          alertControllerWithTitle:@"Success"
                           message:alertMsg
                    preferredStyle:UIAlertControllerStyleAlert];
      UIAlertAction *defaultAction =
          [UIAlertAction actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction *action) {
                                     if (completion) {
                                         completion();
                                     }
                                 }];
      [alertController addAction:defaultAction];
      [self presentViewController:alertController animated:YES completion:nil];
    });
}


#pragma mark - Segmented Tag Quiet Engine
- (void)runNextQuietCycle {
    if (!self.isQuietCycleActive) return;

    [self.quietCycleTimer invalidate];
    self.quietCycleTimer = nil;

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // CHECKPOINT 1
        if (!self.isQuietCycleActive) return;
        
        if (self.inventoryRunning) {
            [[ZebraServiceEngine sharedInstance] sdkStopInventory];
            self.inventoryRunning = NO;
        }
        
        NSString *statusClear = @"";
        [[ZebraServiceEngine sharedInstance] deleteAllPrefilter:nil];
        [[ZebraServiceEngine sharedInstance] restorePrefiltersForTagQuet];
        [[ZebraServiceEngine sharedInstance] resetPrefilters];
        [[ZebraServiceEngine sharedInstance] enableTagQuiet:NO meesage:&statusClear];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            // CHECKPOINT 2
            if (!self.isQuietCycleActive) return;
            
            [self.quietedTagIDs removeAllObjects];
            
            NSArray *selectedTags = [self->_currentlySelectedTagIdObjectArray copy];
            NSInteger totalSelected = selectedTags.count;
            
            if (totalSelected == 0) {
                self.isQuietCycleActive = NO;
                return;
            }
            
            if (self.currentQuietChunkIndex * MAX_SELECTED_TAGS >= totalSelected) {
                self.currentQuietChunkIndex = 0;
            }
            
            NSInteger startIndex = self.currentQuietChunkIndex * MAX_SELECTED_TAGS;
            NSInteger length = MIN(MAX_SELECTED_TAGS, totalSelected - startIndex);
            NSArray *chunk = [selectedTags subarrayWithRange:NSMakeRange(startIndex, length)];
            
            NSMutableArray *prefilterArrayForQuite = [[NSMutableArray alloc] init];
            for (srfidTagData *itemTag in chunk) {
                NSString *tagID = [itemTag getTagId];
                if (tagID == nil) continue;
                
                [self.quietedTagIDs addObject:tagID];
                
                srfidPreFilter *tagFocusFilter = [[srfidPreFilter alloc] init];
                [tagFocusFilter setMaskStartPos:32];
                [tagFocusFilter setMatchLength:96];
                [tagFocusFilter setMatchPattern:tagID];
                [tagFocusFilter setMemoryBank:SRFID_MEMORYBANK_EPC];
                [tagFocusFilter setAction:SRFID_SELECTACTION_INV_B__OR__DSRT_SL];
                [tagFocusFilter setTarget:SRFID_SELECTTARGET_S3];
                [prefilterArrayForQuite addObject:tagFocusFilter];
            }
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                // CHECKPOINT 3
                if (!self.isQuietCycleActive) return;
                
                if (prefilterArrayForQuite.count > 0) {
                    NSString *response = @"";
                    [[ZebraServiceEngine sharedInstance] setPreFilterForTagQuiet:prefilterArrayForQuite status:&response];
                    [[ZebraServiceEngine sharedInstance] enableTagQuiet:YES meesage:&response];
                }
                
                // CHECKPOINT 4
                if (!self.isQuietCycleActive) return;
                
                SRFID_RESULT rfid_res = [[ZebraServiceEngine sharedInstance] sdkStartInventory];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    // CRITICAL CHECKPOINT 5
                    if (!self.isQuietCycleActive) {
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                             [[ZebraServiceEngine sharedInstance] sdkStopInventory];
                        });
                        self.inventoryRunning = NO;
                        return;
                    }
                    
                    [self recalculateColorCounts];
                    [self->tblImpinjInventory reloadData];
                    self->lbGrayCount.text = [[NSNumber numberWithInt:self->coutGray] stringValue];
                    self->lbGreenCount.text = [[NSNumber numberWithInt:self->coutGreen] stringValue];
                    self->lbYellowCount.text = [[NSNumber numberWithInt:self->coutYellow] stringValue];
                    self->lbWhiteCount.text = [[NSNumber numberWithInt:self->coutWhite] stringValue];
                    
                    if (rfid_res == SRFID_RESULT_SUCCESS) {
                        self.inventoryRunning = YES;
                        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"IsInventoryRunning"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        
                        // --- NEW LOGIC: Only apply the cyclic batching if we have MORE than 31 tags ---
                        if (totalSelected > MAX_SELECTED_TAGS) {
                            NSTimeInterval duration = 2.0;
                            NSString *quietTimeText = [self->txtQuietTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            if (quietTimeText.length > 0) {
                                duration = [quietTimeText doubleValue];
                                if (duration <= 0) duration = 2.0;
                            }
                            
                            self.quietCycleTimer = [NSTimer scheduledTimerWithTimeInterval:duration
                                                                                    target:self
                                                                                  selector:@selector(runNextQuietCycle)
                                                                                  userInfo:nil
                                                                                   repeats:NO];
                            self.currentQuietChunkIndex++;
                        } else {
                            // If 31 or fewer tags, DO NOT schedule the timer. Just let it run continuously.
                            NSLog(@"31 or fewer tags selected. Running standard Tag Quiet without batching timer.");
                        }
                        
                    } else {
                        NSLog(@"Cyclic quiet failed to restart inventory hardware.");
                        self.isQuietCycleActive = NO;
                    }
                });
            });
        });
    });
}


- (void)updateActiveTagQuietFilters {
    // Only interrupt the hardware if Tag Quiet is actively running
    if (self.isQuietCycleActive) {
        dispatch_async(dispatch_get_main_queue(), ^{
            // Reset the chunk index so it grabs the freshest list of tags from the top
            self.currentQuietChunkIndex = 0;
            // Trigger the engine to apply the new filters immediately
            [self runNextQuietCycle];
        });
    }
}


// Loading Bar for Tag Quiet and Un-quiet
- (void)showLoadingForSeconds:(NSInteger)seconds
                      message:(NSString *)message
                   completion:(void (^)(void))completion {
    UIView *overlay = [[UIView alloc] initWithFrame:self.view.bounds];
    overlay.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    overlay.tag = 9999;

    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc]
        initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    spinner.color = [UIColor whiteColor];
    spinner.center = overlay.center;
    [spinner startAnimating];

    UILabel *loadingLabel = [[UILabel alloc] init];
    loadingLabel.text = message;
    loadingLabel.textColor = [UIColor whiteColor];
    loadingLabel.font = [UIFont systemFontOfSize:16.0
                                          weight:UIFontWeightMedium];
    loadingLabel.textAlignment = NSTextAlignmentCenter;
    [loadingLabel sizeToFit];
    loadingLabel.center = CGPointMake(overlay.center.x, spinner.center.y + 40);

    [overlay addSubview:spinner];
    [overlay addSubview:loadingLabel];
    [self.view addSubview:overlay];

    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW, (int64_t)(seconds * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
          [UIView animateWithDuration:0.3
              animations:^{
                overlay.alpha = 0.0;
              }
              completion:^(BOOL finished) {
                [overlay removeFromSuperview];
                if (completion) {
                    completion();
                }
              }];
        });
}

- (void)setTagQuietPreFilterArray {
    // Show loader
    [self showLoadingForSeconds:5 message:@"Preparing Cyclic Tag Quiet..." completion:^{
        
        // Setup state
        self.isQuietCycleActive = YES;
        self.currentQuietChunkIndex = 0;

        [self presentAlertWithMessage:@"Tag Quiet is ready. Scan will now start automatically." completion:^{
            
            // 1. Visually set the main Scan button to "Stop"
            [UIView performWithoutAnimation:^{
              [self->btnImpinjInvStart setImage:[UIImage imageNamed:STOP_SCAN_ICON] forState:UIControlStateNormal];
              [self->btnImpinjInvStart setSelected:YES];
              [self->btnImpinjInvStart layoutIfNeeded];
            }];
            
            // 2. --- START MAIN COUNTDOWN TIMER ---
            self->lbTimer.text = @"00:00";
            self.secondsElapsed = 0;
            
            // Save the start time so updateTimer can calculate the difference
            [[NSUserDefaults standardUserDefaults] setObject:[NSDate date] forKey:@"InventoryStartTime"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [self.countdownTimer invalidate];
            self.countdownTimer = [NSTimer timerWithTimeInterval:1.0
                                                          target:self
                                                        selector:@selector(updateTimer)
                                                        userInfo:nil
                                                         repeats:YES];
            [[NSRunLoop mainRunLoop] addTimer:self.countdownTimer forMode:NSRunLoopCommonModes];
            
            // 3. --- START UNIQUE TAG INTERVAL TIMER (Optional but good for your UI) ---
            [self.uniqueTagIntervalTimer invalidate];
            self.uniqueTagCountAtLastInterval = [self->_tagDataInventory count];
            self->lbNewUniqueTagCounter.text = @"New Unique tags every 10s : 0";
            self.uniqueTagIntervalTimer = [NSTimer timerWithTimeInterval:10.0
                                                                  target:self
                                                                selector:@selector(updateNewUniqueTagCount)
                                                                userInfo:nil
                                                                 repeats:YES];
            [[NSRunLoop mainRunLoop] addTimer:self.uniqueTagIntervalTimer forMode:NSRunLoopCommonModes];
            
            // 4. Kick off the rolling segment engine
            [self runNextQuietCycle];
        }];
    }];
}



- (void)showAlert:(NSString *)alertMsg {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.presentedViewController) {
            [self.presentedViewController
                dismissViewControllerAnimated:NO
                                   completion:^{
                                       [self presentAlertWithMessage:alertMsg];
                                   }];
        } else {
            [self presentAlertWithMessage:alertMsg];
        }
        
    });
}


- (void)presentAlertWithMessage:(NSString *)alertMsg {
    dispatch_async(dispatch_get_main_queue(), ^{
      UIAlertController *alertController = [UIAlertController
          alertControllerWithTitle:@"Success"
                           message:alertMsg
                    preferredStyle:UIAlertControllerStyleAlert];

      UIAlertAction *defaultAction =
          [UIAlertAction actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                 handler:nil];

      [alertController addAction:defaultAction];
      [self presentViewController:alertController animated:YES completion:nil];
    });
}

#pragma mark - table view Delegate
- (NSInteger)tableView:(UITableView *)tableView
    numberOfRowsInSection:(NSInteger)section {
    return self.tagDataInventory.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *tagId = @"";

    if (indexPath.row < _tagDataInventory.count) {
        tagId = [_tagDataInventory[indexPath.row] getTagId];
    } else {
        NSLog(@"Warning: Attempted to access index %ld in array with count %lu",
              (long)indexPath.row, (unsigned long)_tagDataInventory.count);
    }

    NSString *tagIdString = [NSString stringWithFormat:@"%@", tagId];
    NSString *tagRSSI = @"";

    if (indexPath.row < _tagDataInventory.count) {
        tagRSSI = [NSString
            stringWithFormat:@"%hd",
                             [_tagDataInventory[indexPath.row] getPeakRSSI]];
    } else {
        NSLog(@"Warning: Attempted to access index %ld in array with count %lu",
              (long)indexPath.row, (unsigned long)_tagDataInventory.count);
    }

    NSString *specificTagId = tagId;
    NSNumber *count = _tagCountDictionary[specificTagId];

    if (count) {
        NSLog(@"TagId: %@, Count: %d", specificTagId, [count intValue]);
    } else {
        NSLog(@"TagId: %@ not found in dictionary", specificTagId);
    }

    // Dequeue and cast to your custom cell
    ImpinjCustomTableViewCell *cell = (ImpinjCustomTableViewCell *)[tableView
        dequeueReusableCellWithIdentifier:@"CustomCell"
                             forIndexPath:indexPath];
    cell.delegate = self;

    if (indexPath.row < self.checkedStates.count) {
        cell.checked = [self.checkedStates[indexPath.row] boolValue];
    } else {
        cell.checked = NO;
    }

    [cell updateCheckboxImage];

    cell.lblImpinjTagID.text = tagIdString;
    cell.lblImpinjRSSI.text = tagRSSI;

    // ── Read count: show -1 for quieted tags ──
    if ([self.quietedTagIDs containsObject:tagIdString]) {
        cell.lblImpinjReadCount.text = @"-1";
    } else {
        cell.lblImpinjReadCount.text = [NSString stringWithFormat:@"%@", count];
    }

    // ── Read rate: show 0.00 for quieted tags ──
    if ([self.quietedTagIDs containsObject:tagIdString]) {
        cell.lblImpinjReadRate.text = @"0.00";
    } else {
        NSNumber *cachedRate = _tagReadRateDictionary[specificTagId];
        if (cachedRate) {
            double tagReadRate = [cachedRate doubleValue];

            int whole = (int)tagReadRate;
            int decimal = (int)((tagReadRate - whole) * 100);

            cell.lblImpinjReadRate.text =
                [NSString stringWithFormat:@"%d.%02d", whole, decimal];
        } else {
            cell.lblImpinjReadRate.text = @"0.00";
        }
    }

    // ── Determine cell background color ──
    // Take a snapshot to avoid mutation-while-enumerating crash
    NSDictionary *avgRateSnapshot = [_tagAvgReadRateDictionary copy];

    double sum = 0.0;
    int activeCount = 0;

    for (NSString *key in avgRateSnapshot) {
        if ([self.quietedTagIDs containsObject:key]) {
            continue;
        }
        sum += [avgRateSnapshot[key] doubleValue];
        activeCount++;
    }

    double averageRate = 0.0;
    if (activeCount > 0) {
        averageRate = sum / activeCount;
    }

    if ([self.quietedTagIDs containsObject:tagIdString]) {
        cell.contentView.backgroundColor = [UIColor colorWithRed:1.0
                                                           green:1.0
                                                            blue:0.8
                                                           alpha:1.0];
    } else {
        NSNumber *specificRate = avgRateSnapshot[tagIdString];
        double rate = [specificRate doubleValue];

        if (rate > averageRate) {
            cell.contentView.backgroundColor = [UIColor colorWithRed:0.80
                                                               green:1.0
                                                                blue:0.80
                                                               alpha:1.0];
        } else if (rate < averageRate) {
            cell.contentView.backgroundColor =
                [UIColor colorWithRed:235.0 / 255.0
                                green:235.0 / 255.0
                                 blue:235.0 / 255.0
                                alpha:1.0];
        } else {
            cell.contentView.backgroundColor = [UIColor whiteColor];
        }
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView
    didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    // We will manage the selection state manually
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    //  Bounds check
    if (indexPath.row >= self.tagDataInventory.count) {
        NSLog(@"Warning: Row %ld out of bounds (count: %lu)",
              (long)indexPath.row, (unsigned long)self.tagDataInventory.count);
        return;
    }

    NSString *selectedTagID =
        [[self.tagDataInventory objectAtIndex:indexPath.row] getTagId];
    NSLog(@"Adrian Selected Tag ID: %@", selectedTagID);

    id selectedObject = [self.tagDataInventory objectAtIndex:indexPath.row];

    // If the row is already selected, deselect it
    if ([self.selectedRows containsObject:indexPath]) {
        [self.selectedRows removeObject:indexPath];
        [_currentlySelectedTagIdObjectArray removeObject:selectedObject];
    }
    // If the row is not selected, select it
    else {
          //Check limit before selecting
        if (_currentlySelectedTagIdObjectArray.count >= MAX_SELECTED_TAGS) {
            [self
             showAlert:[NSString stringWithFormat:@"Maximum selection limit "
                        @"of %d tags reached.",
                        MAX_SELECTED_TAGS]];
            return;
        }
        
        [self.selectedRows addObject:indexPath];
        [_currentlySelectedTagIdObjectArray addObject:selectedObject];
        
        
    }

    //  Toggle the checkbox state when the row is tapped
    if (indexPath.row < self.checkedStates.count) {
        BOOL newState = ![self.checkedStates[indexPath.row] boolValue];
        self.checkedStates[indexPath.row] = @(newState);
    }
    
    [self updateSelectAllButtonState];
    
    [self updateActiveTagQuietFilters];

    // Inform the delegate (ProtectedVC)
    if ([self.delegate respondsToSelector:@selector(inventoryVC:
                                                  didSelectItem:)]) {
        [self.delegate inventoryVC:self didSelectItem:selectedTagID];
    }

    NSLog(@"Adrian currentlySelectedTagIdObjectArray Count: %lu",
          (unsigned long)[_currentlySelectedTagIdObjectArray count]);

    // Save to NSUserDefaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:selectedTagID forKey:@"SelectedTagID"];
    [defaults synchronize];

    // Reload the row to update its appearance
    [tableView reloadRowsAtIndexPaths:@[ indexPath ]
                     withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (void)resetReadRate {
    //    _scanStartTime = nil;
    //    _totalReadCount = 0;
    //   // [_tagCountDictionary removeAllObjects];
}

#pragma mark - CustomTableViewCellDelegate

- (void)customCellCheckBoxButtonTapped:(ImpinjCustomTableViewCell *)cell {

    NSIndexPath *indexPath = [self->tblImpinjInventory indexPathForCell:cell];
    if (indexPath) {
        if (indexPath.row >= self.tagDataInventory.count ||
            indexPath.row >= self.checkedStates.count) {
            NSLog(@"Warning: Row %ld out of bounds", (long)indexPath.row);
            return;
        }

        BOOL currentState = [self.checkedStates[indexPath.row] boolValue];
        BOOL newState = !currentState;

        // Check limit before checking a new checkbox
        if (newState &&
            _currentlySelectedTagIdObjectArray.count >= MAX_SELECTED_TAGS) {
            [self
                showAlert:[NSString stringWithFormat:@"Maximum selection limit "
                                                     @"of %d tags reached.",
                                                     MAX_SELECTED_TAGS]];
            return;
        }

        self.checkedStates[indexPath.row] = @(newState);

        cell.checked = newState;
        [cell updateCheckboxImage];
        
        [self updateSelectAllButtonState];
        
        [self updateActiveTagQuietFilters];

        id selectedObject = [self.tagDataInventory objectAtIndex:indexPath.row];
        NSString *selectedTagID = [selectedObject getTagId];

        if (newState) {
            if (![self.selectedRows containsObject:indexPath]) {
                [self.selectedRows addObject:indexPath];
            }
            [_currentlySelectedTagIdObjectArray addObject:selectedObject];
        } else {
            [self.selectedRows removeObject:indexPath];
            [_currentlySelectedTagIdObjectArray removeObject:selectedObject];
        }

        if ([self.delegate respondsToSelector:@selector(inventoryVC:
                                                      didSelectItem:)]) {
            [self.delegate inventoryVC:self didSelectItem:selectedTagID];
        }

        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:selectedTagID forKey:@"SelectedTagID"];
        [defaults synchronize];

        NSLog(@"Checkbox tapped — currentlySelectedTagIdObjectArray Count: %lu",
              (unsigned long)[_currentlySelectedTagIdObjectArray count]);

        [self->tblImpinjInventory
            reloadRowsAtIndexPaths:@[ indexPath ]
                  withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma mark - IBAction Methods
- (IBAction)btnSelectAllTaggPressed:(id)sender {

    if (btnSlectAllTags.selected == YES) {
        // checkbox_checked_icon  checkbox_icon
        [UIView performWithoutAnimation:^{
          [btnSlectAllTags setImage:[UIImage imageNamed:@"checkbox_icon"]
                           forState:UIControlStateNormal];
          [btnSlectAllTags layoutIfNeeded];
          [btnSlectAllTags setSelected:NO];
        }];

        [self selectAllTagInTableView:NO];
    } else {
        // checkbox_checked_icon  checkbox_icon
        [UIView performWithoutAnimation:^{
          [btnSlectAllTags
              setImage:[UIImage imageNamed:@"checkbox_checked_icon"]
              forState:UIControlStateNormal];
          [btnSlectAllTags layoutIfNeeded];
          [btnSlectAllTags setSelected:YES];
        }];
        [self selectAllTagInTableView:YES];
    }
}
- (IBAction)btnClearInventoryPressed:(id)sender {
    //  Full clear — including quieted tags
    [self.quietedTagIDs removeAllObjects];
    [self resetInventoryState];

    // Also stop all timers
    [self.countdownTimer invalidate];
    self.countdownTimer = nil;
    [self.inventoryAutoStopTimer invalidate];
    self.inventoryAutoStopTimer = nil;
    [self.uniqueTagIntervalTimer invalidate];
    self.uniqueTagIntervalTimer = nil;
   
    self.secondsElapsed = 0;

    self->lbTimer.text = @"00:00";

    //  Clear saved times
    [[NSUserDefaults standardUserDefaults] setBool:NO
                                            forKey:@"IsInventoryRunning"];
    [[NSUserDefaults standardUserDefaults]
        removeObjectForKey:@"InventoryStartTime"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)selectAllTagInTableView:(BOOL)enableAll {
    // Reset all selection tracking
    [self.checkedStates removeAllObjects];
    [self.selectedRows removeAllObjects];
    [_currentlySelectedTagIdObjectArray removeAllObjects];
    
    for (int i = 0; i < [_tagDataInventory count]; i++) {
        if (enableAll) {
            // 1. ALWAYS select the tag in the background data, regardless of index
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:0];
            [self.selectedRows addObject:indexPath];
            [_currentlySelectedTagIdObjectArray addObject:_tagDataInventory[i]];
            
            // 2. ONLY apply the visual checkmark to the first 31 tags
            if (i < MAX_SELECTED_TAGS) {
                [self.checkedStates addObject:@(YES)];
            } else {
                [self.checkedStates addObject:@(NO)];
            }
        } else {
            // If deselecting all, clear visual checkmarks
            [self.checkedStates addObject:@(NO)];
        }
    }
    // Optional: Show warning if there were more tags than the limit
//    if (enableAll && _tagDataInventory.count > MAX_SELECTED_TAGS) {
//        [self showAlert:[NSString stringWithFormat:
//                                      @"Only the first %d tags were selected.",
//                                      MAX_SELECTED_TAGS]];
//    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self->tblImpinjInventory reloadData];
    });
    
    [self updateActiveTagQuietFilters];
    
    NSLog(@"Currently Selected Array Count: %lu", (unsigned long)[_currentlySelectedTagIdObjectArray count]);
}


- (void)updateSelectAllButtonState {
    BOOL isSelectAllState = YES;
    
    if (self.tagDataInventory.count == 0) {
        isSelectAllState = NO;
    } else {
        // Check if the current state perfectly matches the "Select All" criteria
        for (int i = 0; i < self.checkedStates.count; i++) {
            BOOL isChecked = [self.checkedStates[i] boolValue];
            
            if (i < MAX_SELECTED_TAGS) {
                // If any of the first 31 tags are UNCHECKED, it's not "Select All"
                if (!isChecked) {
                    isSelectAllState = NO;
                    break;
                }
            } else {
                // If any tag AFTER the 31st is CHECKED, it's not "Select All"
                if (isChecked) {
                    isSelectAllState = NO;
                    break;
                }
            }
        }
    }
    
    // Update the UI
    dispatch_async(dispatch_get_main_queue(), ^{
        if (isSelectAllState) {
            if (!self->btnSlectAllTags.isSelected) {
                [UIView performWithoutAnimation:^{
                    [self->btnSlectAllTags setImage:[UIImage imageNamed:@"checkbox_checked_icon"] forState:UIControlStateNormal];
                    [self->btnSlectAllTags setSelected:YES];
                    [self->btnSlectAllTags layoutIfNeeded];
                }];
            }
        } else {
            if (self->btnSlectAllTags.isSelected) {
                [UIView performWithoutAnimation:^{
                    [self->btnSlectAllTags setImage:[UIImage imageNamed:@"checkbox_icon"] forState:UIControlStateNormal];
                    [self->btnSlectAllTags setSelected:NO];
                    [self->btnSlectAllTags layoutIfNeeded];
                }];
            }
        }
    });
}



- (IBAction)btnEnableFastID:(id)sender {

    if (btnFastID.isSelected) {

        // 1. Update UI immediately on the Main Thread
        [UIView performWithoutAnimation:^{
          [btnFastID setImage:[UIImage imageNamed:@"checkbox_icon"]
                     forState:UIControlStateNormal];
          [btnFastID setSelected:NO];
          [btnFastID layoutIfNeeded];
        }];

        // 2. Send hardware command on a background thread
        dispatch_async(
            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
              // Hardware call
              SRFID_RESULT resConfigureFastIDFinal =
                  [[ZebraServiceEngine sharedInstance] configureFastID:NO
                                                                status:nil];
              if (resConfigureFastIDFinal == SRFID_RESULT_SUCCESS) {
                  [[ZebraServiceEngine sharedInstance]
                      setFastIDEnableStatue:NO];
                  [[NSUserDefaults standardUserDefaults]
                      setBool:YES
                       forKey:@"FastIDEnabled"];
                  [[NSUserDefaults standardUserDefaults] synchronize];
              }
              // Switch back to Main Thread for UI Alert
              dispatch_async(dispatch_get_main_queue(), ^{
                if (resConfigureFastIDFinal == SRFID_RESULT_SUCCESS) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Fast ID Disabled"];
                    });

                } else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Failed to Disable Fast ID"];
                    });

                    // Optional: If it failed, you might want to revert the
                    // checkbox UI here
                }
              });
            });

    } else {

        // 1. Update UI immediately on the Main Thread
        [UIView performWithoutAnimation:^{
          [btnFastID setImage:[UIImage imageNamed:@"checkbox_checked_icon"]
                     forState:UIControlStateNormal];
          [btnFastID setSelected:YES];
          [btnFastID layoutIfNeeded];
        }];

        // 2. Send hardware command on a background thread
        dispatch_async(
            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
              // Do ALL hardware calls on the background thread!

              // Check the result of enabling Fast ID
              SRFID_RESULT resConfigureFastIDFinal =
                  [[ZebraServiceEngine sharedInstance] configureFastID:YES
                                                                status:nil];

              if (resConfigureFastIDFinal == SRFID_RESULT_SUCCESS) {
                  //[self enableFastID];
                  [[ZebraServiceEngine sharedInstance]
                      setFastIDEnableStatue:YES];
                  [[NSUserDefaults standardUserDefaults]
                      setBool:YES
                       forKey:@"FastIDEnabled"];
                  [[NSUserDefaults standardUserDefaults] synchronize];
              }

              // Switch back to Main Thread ONLY for the UI Alert
              dispatch_async(dispatch_get_main_queue(), ^{
                if (resConfigureFastIDFinal == SRFID_RESULT_SUCCESS) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Fast ID Enabled"];
                    });

                } else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                      [self showAlert:@"Failed to Enable Fast ID"];
                    });
                }
              });
            });
    }
}

//-(void)enableFastID {
//
//    srfidSingulationConfig *singulationConfig = [[ZebraServiceEngine
//    sharedInstance] getSingulationConfiguration];
//
//    if (singulationConfig) {
//        [singulationConfig setSession:SRFID_SESSION_S1];
//        [singulationConfig setInventoryState:SRFID_INVENTORYSTATE_A];
//        [singulationConfig setSlFlag:SRFID_SLFLAG_ALL];
//        [singulationConfig setTagPopulation:30];
//
//        [[ZebraServiceEngine sharedInstance]
//        setSingulationConfiguration:singulationConfig];
//    } else {
//        NSLog(@"Error: Could not retrieve singulation config from Zebra
//        reader.");
//    }
//}

- (IBAction)btnStartStopPressed:(id)sender {
    if (self.inventoryStartStopInProgress) {
        return;
    }

    if (btnImpinjInvStart.isSelected) {

        // --- STOP ---
        self.inventoryStartStopInProgress = YES;
        [UIView performWithoutAnimation:^{
          [btnImpinjInvStart setImage:[UIImage imageNamed:START_SCAN_ICON]
                             forState:UIControlStateNormal];
          [btnImpinjInvStart setSelected:NO];
          [btnImpinjInvStart layoutIfNeeded];
        }];

        [self stopInventoryAndTimers];

    } else {

        // --- START ---
        self.inventoryStartStopInProgress = YES;
        [UIView performWithoutAnimation:^{
          [btnImpinjInvStart setImage:[UIImage imageNamed:STOP_SCAN_ICON]
                             forState:UIControlStateNormal];
          [btnImpinjInvStart setSelected:YES];
          [btnImpinjInvStart layoutIfNeeded];
        }];
        
        self->lbTimer.text = @"00:00";
        // ── Elapsed timer ──
        [self.countdownTimer invalidate];
        self.countdownTimer = nil;
        self.secondsElapsed = 0;
        //  Save the start time so it survives navigation
        [[NSUserDefaults standardUserDefaults] setObject:[NSDate date]
                                                  forKey:@"InventoryStartTime"];
        [[NSUserDefaults standardUserDefaults] synchronize];

        self.countdownTimer =
            [NSTimer timerWithTimeInterval:1.0
                                    target:self
                                  selector:@selector(updateTimer)
                                  userInfo:nil
                                   repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:self.countdownTimer
                                  forMode:NSRunLoopCommonModes];

        // ── Unique tag interval timer ──
        [self.uniqueTagIntervalTimer invalidate];
        self.uniqueTagIntervalTimer = nil;
        self.uniqueTagCountAtLastInterval = [_tagDataInventory count];
        self->lbNewUniqueTagCounter.text = @"New Unique tags every 10s : 0";

        self.uniqueTagIntervalTimer =
            [NSTimer timerWithTimeInterval:10.0
                                    target:self
                                  selector:@selector(updateNewUniqueTagCount)
                                  userInfo:nil
                                   repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:self.uniqueTagIntervalTimer
                                  forMode:NSRunLoopCommonModes];

        // ── Auto-stop timer ──
        [self.inventoryAutoStopTimer invalidate];
        self.inventoryAutoStopTimer = nil;

        NSString *inventoryTimeText = [self->txtInventoryTime.text
            stringByTrimmingCharactersInSet:
                [NSCharacterSet whitespaceAndNewlineCharacterSet]];

        if (inventoryTimeText.length > 0) {
            NSInteger seconds = [inventoryTimeText integerValue];
            if (seconds > 0) {
                self.inventoryAutoStopTimer =
                    [NSTimer timerWithTimeInterval:seconds
                                            target:self
                                          selector:@selector(autoStopInventory)
                                          userInfo:nil
                                           repeats:NO];
                [[NSRunLoop mainRunLoop] addTimer:self.inventoryAutoStopTimer
                                          forMode:NSRunLoopCommonModes];
            }
        }
        
       

        // Start hardware scan in background
        dispatch_async(
            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
              [self inventoryStart];
            });
    }
}

#pragma mark - Auto Stop Inventory

- (void)autoStopInventory {
    // Update button UI back to "Start" state
    [UIView performWithoutAnimation:^{
      [btnImpinjInvStart setImage:[UIImage imageNamed:START_SCAN_ICON]
                         forState:UIControlStateNormal];
      [btnImpinjInvStart setSelected:NO];
      [btnImpinjInvStart layoutIfNeeded];
    }];

    [self stopInventoryAndTimers];
}

- (void)stopInventoryAndTimers {
    // Stop the elapsed timer
    [self.countdownTimer invalidate];
    self.countdownTimer = nil;
    NSLog(@"Timer stopped at %d seconds.", self.secondsElapsed);

    // Stop the auto-stop timer
    [self.inventoryAutoStopTimer invalidate];
    self.inventoryAutoStopTimer = nil;

    //  Stop the unique tag interval timer
    [self.uniqueTagIntervalTimer invalidate];
    self.uniqueTagIntervalTimer = nil;
    
    // Kill Tag Quiet rolling cycle
    self.isQuietCycleActive = NO;
    [self.quietCycleTimer invalidate];
    self.quietCycleTimer = nil;

    
    //  Clear the saved start time
    [[NSUserDefaults standardUserDefaults]
        removeObjectForKey:@"InventoryStartTime"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    // Stop hardware scan in background
    dispatch_async(
        dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
          [self inventoryStop];
        });
}

- (void)updateTimer {
    NSDate *startTime = [[NSUserDefaults standardUserDefaults] objectForKey:@"InventoryStartTime"];
    if (!startTime) return;

    self.secondsElapsed = (int)[[NSDate date] timeIntervalSinceDate:startTime];

    int minutes = self.secondsElapsed / 60;
    int seconds = self.secondsElapsed % 60;

    self->lbTimer.text = [NSString stringWithFormat:@"%02d:%02d", minutes, seconds];

    // ---- keep alert in sync with the same timer ----
    if (self.readRateAlert) {
        NSTimeInterval elapsed = (NSTimeInterval)self.secondsElapsed; // same as label
        NSInteger totalReads = self->_totalReadCount;
        double readRate = (elapsed > 0) ? ((double)totalReads / elapsed) : 0.0;

        [self.readRateAlert configureWithTotalReads:totalReads
                                          totalTime:elapsed
                                           readRate:readRate];
    }
}

- (void)dealloc {
    [self.countdownTimer invalidate]; // Clean up to prevent retain cycle

    [self.inventoryAutoStopTimer invalidate];
    [self.uniqueTagIntervalTimer invalidate];
    [self.quietCycleTimer invalidate];
}

- (void)clearAllSelections {
    // 1. Clear the array that stores the selected index paths.
    [self.selectedRows removeAllObjects];

    // 2. Clear the array that stores your selected tag data objects.
    [_currentlySelectedTagIdObjectArray removeAllObjects];

    NSLog(@"All selections have been cleared.");
}
#pragma mark - Inventory Start
- (void)inventoryStart {
    @try {
        // Clear everything for a fresh start (preserves quieted tags)
        dispatch_sync(dispatch_get_main_queue(), ^{
          [self resetInventoryState];
        });

        // Now start the hardware scan
        SRFID_RESULT rfid_res = SRFID_RESULT_FAILURE;

        if (_hasTagFocusEnabled) {
            [self setSingulationForTagFocus];
        }

        rfid_res = [[ZebraServiceEngine sharedInstance] sdkStartInventory];
        if (rfid_res == SRFID_RESULT_SUCCESS) {
            self.inventoryRunning = YES;
            [[NSUserDefaults standardUserDefaults]
                setBool:YES
                 forKey:@"IsInventoryRunning"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            NSLog(@" sdkStartInventory : Success");
        } else if (rfid_res == SRFID_RESULT_RESPONSE_ERROR) {
            self.inventoryRunning = NO;
            NSLog(@"sdkStartInventory ResponseError");
        } else if (rfid_res == SRFID_RESULT_FAILURE ||
                   rfid_res == SRFID_RESULT_RESPONSE_TIMEOUT) {
            self.inventoryRunning = NO;
            NSLog(@"sdkStartInventory reader prob");
        }
    } @finally {
        self.inventoryStartStopInProgress = NO;
    }
}

- (void)inventoryStop {
    @try {
        SRFID_RESULT rfid_res = SRFID_RESULT_FAILURE;
        rfid_res = [[ZebraServiceEngine sharedInstance] sdkStopInventory];
        self.inventoryRunning = NO;

        [[NSUserDefaults standardUserDefaults] setBool:NO
                                                forKey:@"IsInventoryRunning"];
        [[NSUserDefaults standardUserDefaults] synchronize];

        dispatch_async(dispatch_get_main_queue(), ^{
          [self->tblImpinjInventory reloadData];
        });

        if (rfid_res == SRFID_RESULT_SUCCESS) {
            NSLog(@" inventoryStop : Success");
        } else if (rfid_res == SRFID_RESULT_RESPONSE_ERROR) {
            NSLog(@"inventoryStop ResponseError");
        } else if (rfid_res == SRFID_RESULT_FAILURE ||
                   rfid_res == SRFID_RESULT_RESPONSE_TIMEOUT) {
            NSLog(@"inventoryStop reader prob");
        }

        [self resetReadRate];
    } @finally {
        self.inventoryStartStopInProgress = NO;
    }
}

#pragma mark - Trigger Event

- (BOOL)onNewTriggerEvent:(BOOL)pressed typeRFID:(BOOL)isRFID {
    if (!isRFID) {
        return YES;
    }

    __block InventoryVC *__weak_self = self;

    BOOL running = self.inventoryRunning;
    BOOL busy = self.inventoryStartStopInProgress;

    NSLog(@"[DEBUG] Trigger pressed=%d running(flag)=%d busy=%d UISelected=%d",
          pressed, running, busy, self->btnImpinjInvStart.isSelected);

    if (pressed) {
        // PRESS -> START
        if (YES == [[[ZebraServiceEngine sharedInstance] sledConfiguration]
                       isStartTriggerImmediate]) {
            if (!running && !busy) {
                dispatch_async(dispatch_get_main_queue(), ^{
                  if (!__weak_self.inventoryRunning &&
                      !__weak_self.inventoryStartStopInProgress) {
                      if (!__weak_self->btnImpinjInvStart.isSelected) {
                          [__weak_self btnStartStopPressed:nil];
                      } else {
                          __weak_self.inventoryStartStopInProgress = YES;
                          dispatch_async(
                              dispatch_get_global_queue(
                                  DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),
                              ^{
                                [__weak_self inventoryStart];
                              });
                      }
                  }
                });
            }
        }
    } else {
        // RELEASE -> STOP
        if (YES == [[[ZebraServiceEngine sharedInstance] sledConfiguration]
                       isStopTriggerImmediate]) {
            if (running && !busy) {
                dispatch_async(dispatch_get_main_queue(), ^{
                  if (__weak_self.inventoryRunning &&
                      !__weak_self.inventoryStartStopInProgress) {
                      if (__weak_self->btnImpinjInvStart.isSelected) {
                          [__weak_self btnStartStopPressed:nil];
                      } else {
                          [__weak_self stopInventoryAndTimers];
                          [__weak_self->btnImpinjInvStart
                              setImage:[UIImage imageNamed:START_SCAN_ICON]
                              forState:UIControlStateNormal];
                          [__weak_self->btnImpinjInvStart setSelected:NO];
                          [__weak_self->btnImpinjInvStart layoutIfNeeded];

                          __weak_self.inventoryRunning = NO;
                      }
                  }
                });
            }
        }
    }

    return YES;
}

#pragma mark - TextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {

    if (textField == self->txtQuietTime) {
        [textField resignFirstResponder];
        [self showNumberInputAlertWithTitle:@"Quiet Time"
                                    message:@"Please Enter Quiet Time below."
                                placeholder:@"Quiet Time"
                                 completion:^(NSString *enteredText) {
                                   self->txtQuietTime.text = enteredText;
                                 }];
    } else if (textField == self->txtInventoryTime) {
        [textField resignFirstResponder];
        [self
            showNumberInputAlertWithTitle:@"Inventory Time"
                                  message:@"Please Enter Inventory Time below."
                              placeholder:@"Inventory Time"
                               completion:^(NSString *enteredText) {
                                 self->txtInventoryTime.text = enteredText;
                               }];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)showNumberInputAlertWithTitle:(NSString *)title
                              message:(NSString *)message
                          placeholder:(NSString *)placeholder
                           completion:
                               (void (^)(NSString *enteredText))completion {

    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:title
                         message:message
                  preferredStyle:UIAlertControllerStyleAlert];

    [alert addTextFieldWithConfigurationHandler:^(
               UITextField *_Nonnull textField) {
      textField.keyboardType = UIKeyboardTypeNumberPad;
      textField.placeholder = placeholder;
    }];

    UIAlertAction *cancel =
        [UIAlertAction actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleCancel
                               handler:nil];

    UIAlertAction *ok = [UIAlertAction
        actionWithTitle:@"OK"
                  style:UIAlertActionStyleDefault
                handler:^(UIAlertAction *action) {
                  NSString *enteredText = alert.textFields.firstObject.text;
                  if (completion) {
                      completion(enteredText);
                  }
                }];

    [alert addAction:cancel];
    [alert addAction:ok];

    [self presentViewController:alert animated:YES completion:nil];
}

@end

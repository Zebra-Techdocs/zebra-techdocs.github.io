//
//  AppDelegate.h
//  NewGen2XPlay
//
//  Created by Dhanushka, Adrian on 2026-02-16.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end


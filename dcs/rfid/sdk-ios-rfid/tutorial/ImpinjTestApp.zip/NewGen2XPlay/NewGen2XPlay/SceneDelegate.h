//
//  SceneDelegate.h
//  NewGen2XPlay
//
//  Created by Dhanushka, Adrian on 2026-02-16.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


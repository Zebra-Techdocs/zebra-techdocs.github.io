//
//  ViewController.m
//  NewGen2XPlay
//
//  Created by Dhanushka, Adrian on 2026-02-16.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end

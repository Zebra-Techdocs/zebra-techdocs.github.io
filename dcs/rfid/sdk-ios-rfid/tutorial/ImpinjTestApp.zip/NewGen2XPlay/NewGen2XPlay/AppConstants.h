//
//  AppConstants.h
//  NewGen2XPlay
//
//  Created by Kakarlapudi, Prudhvi on 13/04/26.
//


// General
#define APP_INFO   @"App Info"
#define ZT_RFID_APP_NAME       @"ZebraGen2X Application"

// Inventory Protocol
#define INVENTORY_PROTOCOL_VC_TITLE   @"Inventory Protocol"
#define SELECTED_PROTOCOL_KEY   @"SelectedInventoryProtocol"

